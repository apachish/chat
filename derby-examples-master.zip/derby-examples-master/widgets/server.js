require('derby-starter').run(__dirname, {port: 8008});
